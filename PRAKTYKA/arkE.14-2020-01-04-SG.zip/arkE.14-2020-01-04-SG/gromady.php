<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gromady kręgowców</title>
    <link rel="stylesheet" href="style12.css">
</head>
<body>
    <div class="menu">
        <a href="./gromada-ryby.html">gromada ryb</a>
        <a href="./gromada-ptaki.html">gromada ptaków</a>
        <a href="./gromada-ssaki.html">gromada ssaków</a>
    </div>
    <div class="logo">
        <h2>GROMADY KRĘGOWCÓW</h2>
    </div>
    <div class="lewy">
        <?php //Skrypt 1
        
        ?>
    </div>
    <div class="prawy">
        <h1>PTAKI</h1>
        <ol>
            <?php //skrypt 2

            ?>
        </ol>
        <img src="./sroka.jpg" alt="Sroka zwyczajna, gromada ptaki">
    </div>
    <div class="stopka">
        Stronę o kręgowcach przygotował: Maciej Glugla
    </div>
</body>
</html>